<!DOCTYPE html>
<html>
 <head>
  <title>about us </title>
     <link rel="stylesheet" href="css/about.css"
 </head>
 <body>
     
     <div class="header">
         
     <div class="main">
         <h1>About Us</h1>
     <p>Say goodbye to the old and tiresome process of leave approvals over phone or emails and say 'Hi' to student attendance systems. Our cloud based attendance management software lets your students tackle leave requests with ease. You can view students leave balance, holiday list and any other records anytime anywhere. With the support of leave management software, you can process various leave requests with ease and employees can also receive their responses in a quick way.</p>    
         </div>
     
      </div>
     </body>
     
     